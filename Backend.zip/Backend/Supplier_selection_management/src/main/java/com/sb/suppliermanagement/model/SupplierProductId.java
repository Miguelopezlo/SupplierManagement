//package com.sb.suppliermanagement.model;
//
//
//import java.io.Serializable;
//
//import javax.persistence.Column;
//import javax.persistence.Embeddable;
//
//
//
//
//@Embeddable
//public class SupplierProductId implements Serializable{
//
//	private static final long serialVersionUID = 2331780950815220159L;
//
//	@Column(name = "supplierid")
//	private Supplier supplierid;
//	
//	@Column(name = "productid")
//	private Product productid;
//	
//
//}

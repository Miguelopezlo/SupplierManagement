package com.sb.suppliermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplierSelectionManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplierSelectionManagementApplication.class, args);
	}

}
